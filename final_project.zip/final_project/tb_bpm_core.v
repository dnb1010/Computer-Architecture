module tb_bpm_core;

reg clk;
reg rst;
reg [9:0] singal_in;

wire peak;
wire [31:0] rr_interval;
wire [15:0] bpm;
wire abnormal;

// Instantiate từng module
peak_detector u1(clk, rst, signal_in, peak);
rr_interval_counter u2(clk, rst, peak, rr_interval);
bpm_calculator u3(clk, rst, rr_interval, bpm);
arrhythmia_detector u4(bpm, abnormal);

// Clock 100Hz -> #10 mỗi chu kỳ
always #5 clk = ~clk;

// Task tạo tín hiệu giống "đã lọc sạch"
task generate_clean_ecg;
    input integer interval; // Khoảng cách giữa peak
    input integer beats;    // Số nhịp
    integer ;

begin
    for (i = 0; i < beats ; i = i + 1 ) begin
        for (j = 0; j < interval ; j = j + 1 ) begin
            // Dạng sóng mượt (giống đã filter)
            if (j == 0)
                signal_in = 2000; // đỉnh
            else if (j < 5)
                signal_in = 1000; // sườn xuống
            else
                signal_in = 300; // baseline
            #10;
        end
    end
end
endtask

initial begin
    clk = 0;
    rst = 1;
    signal_in = 0;

    #20 rst = 0;

    // ========================
    // Test 1: 75 BPM
    // rr = 90 -> 6000/80 = 75
    // ========================
    $display("==== TEST 76 BPM ====");
    generate_clean_ecg(80, 5)


    // ========================
    // TEST 2: 130 BPM
    // rr = 46 -> 6000/46 =130
    // ========================
    $display("==== TEST 130 BPM ====");
    generate_clean_ecg(46, 5);

    #100 $stop;
end