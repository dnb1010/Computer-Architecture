module bpm_calculator (
    input clk,
    input rst,
    input [31:0] rr_interval, // số clock giữ 2 nhịp (có thể lớn -> dùng 32 bit)
    output reg [15:0] bpm // kết quả (0 -> vài trăm -> 16-bit là đủ lớn)
);
parameter CLK_FREQ = 100; // Hz

always @(posedge clk or posedge rst) begin
    if (rst)
        bpm <= 0;
    else if (rr_interval != 0)
        bpm <= (60 * CLK_FREQ) / rr_interval;
end
endmodule